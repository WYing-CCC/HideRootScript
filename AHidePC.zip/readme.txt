丨中文（简体）丨中文（繁体）丨English丨



丨中文（简体）丨
在使用这个脚本之前，您需要准备以下基础服务：
电脑：
最低Windows版本：Windows10/专业版/专业工作站版 1803版本往上 ↑
推荐Windows版本：Windows11/专业版/专业工作站版 23H2 或者Windows11/专业版/专业工作站版 24H2 26100.4061
最低终端版本：Windows Terminal4.0
推荐终端版本：Windows Terminal4.6/Windows Terminal Preview 4.8
需要操控的设备（手机/平板）：
请确保 手机/平板 已解锁 BootLoader
请确保 手机/平板 已安装 Magisk / APatch /KernelSU

此脚本内置 Adb / FastBoot 命令集，无需安装 Adb / FastBoot



丨中文（繁体）丨
在使用這個腳本之前，您需要準備以下基礎服務：
電腦：
最低Windows版本：Windows10/專業版/專業工作站版 1803版本往上 ↑
推薦Windows版本：Windows11/專業版/專業工作站版 23H2 或者Windows11/專業版/專業工作站版 24H2 26100.4061
最低終端版本：Windows Terminal4.0
推薦終端版本：Windows Terminal4.6/Windows Terminal Preview 4.8
需要操控的設備（手機/平板）：
請確保手機/平板 已解鎖 BootLoader
請確保 手機/平板 已安裝Magisk / APatch /KernelSU

此腳本內置 Adb / FastBoot 命令集，無需安裝 Adb / FastBoot



丨English丨
Before using this script, you need to prepare the following basic services:
Computer:
Minimum Windows version: Windows 10/Professional/Professional Workstation Edition 1803 version ↑
Recommended Windows version: Windows 11/Professional/Professional Workstation Edition 23H2 or Windows 11/Professional/Professional Workstation Edition 24H2 26100.4061
Minimum terminal version: Windows Terminal 4.0
Recommended terminal version: Windows Terminal 4.6/Windows Terminal Preview 4.8
Device to be controlled (phone/tablet):
Please make sure your phone/tablet is unlocked with BootLoader
Please make sure that your phone/tablet has Magisk / APatch /KernelSU installed

This script has a built-in Adb / FastBoot command set, no need to install Adb / FastBoot